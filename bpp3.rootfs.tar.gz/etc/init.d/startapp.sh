#!/bin/sh
### BEGIN INIT INFO
# Provides:          startapp
# Required-Start:
# Required-Stop:
# Default-Start:     S
# Default-Stop:      0 6
# Short-Description: starts user app.
### END INIT INFO

. /etc/default/rcS

echo "****** Starting Application meta-bpp3 ******"
